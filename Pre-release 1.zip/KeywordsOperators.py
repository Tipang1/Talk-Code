# Mots-clés & opérateurs
KEYWORDS = {
    'is',
    'say',
    'if', 'else',
    'convert', 'to', 'as',
    'int', 'float', 'string', 'bool',
    'plus', 'minus',
    'times', 'divided', 'by',
    'repeat',
    'while',
    'ask'
}

OPERATORS = {
    '+', '-', '*', '/',
    '<', '>', '='
}
